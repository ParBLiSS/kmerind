#pragma once

#ifdef NDEBUG
#   define _SECURE_SCL 0
#endif

#include "../../relacy/pch.hpp"

