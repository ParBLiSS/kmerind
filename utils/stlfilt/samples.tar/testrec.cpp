//
// test recursive templates:
//

#include <iostream>
#include <set>
#include <vector>
#include <algorithm>

int main()
{
	using namespace std;

	set<vector<double> > mySet;
	vector<double> foo;

	for (int i = 0; i < 10; i++)
		mySet.insert(foo);

	mySet.add("five");
	mySet.add(foo);
	mySet = foo;

	set<int>::iterator firstFive = //find(mySet.begin(), mySet.end(), 5);
								  50;

	if (firstFive != mySet.end())
		cout << "Found it!" << endl;
	else
		cout << "Not found." << endl;

	return 0;
}
