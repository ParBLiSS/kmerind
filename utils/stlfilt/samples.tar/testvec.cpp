#include <iostream>
#include <vector>
#include <string>

#include "Widget.h"

int main(int argc, char **argv)
{
	using namespace std;
//	cout << "command line: ";
	char cmdline[100] = "cl2 ";

	vector<int> v0("hello");
	vector<Widget> v(1,2,3,4,5,6);
	v.foobar();
	string foo(1,2,3,4,5);
	for (int i = 1; i < argc; i++)
	{
//		cout << argv[i] << " ";
		strcat(cmdline, argv[i]);
		strcat(cmdline, " ");
	}
	strcat(cmdline, " | perl d:\\src\\cl\\filt2.pl");

	cout << "complete command line: " << cmdline << endl;
	system(cmdline);
//	cout << argv[1] << "(3): error C1000: this is a test error" << endl;
//	cout << argv[1] << "(5): error C1000: this is a another test error" << endl;
	return 0;
}
