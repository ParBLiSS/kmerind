#include <string>
#include <iostream>
#include <fstream>
#include <deque>
#include <set>
#include "Widget.h"

int main()
{
	using namespace std;

//	ifstream storedWidgets("foo");
	ifstream storedWidgets();

// doesn't seem to work for either Microsoft vc++6 w/Dinkumware OR Borland 5.5:

//	deque<Widget> wd(istream_iterator<Widget>(storedWidgets), 10);
	deque<Widget> wd(istream_iterator<Widget>(storedWidgets), istream_iterator<Widget>());

	set<deque<Widget> >wd2(istream_iterator<deque<Widget> >(storedWidgets), istream_iterator<deque<Widget> >());

// while this works with both:
	
	deque<Widget> wd2(10,2);

//	wd.foo();
	copy(istream_iterator<Widget>(storedWidgets), istream_iterator<Widget>(),
       back_inserter(wd));

	copy(istream_iterator<deque<Widget> >(storedWidgets), istream_iterator<deque<Widget> >(),
       back_inserter(wd));

	return 0;
}
