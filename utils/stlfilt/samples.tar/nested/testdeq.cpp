#include <string>
#include <iostream>
#include <fstream>
#include <deque>
#include <list>

#include "Widget.h"

int main()
{
	using namespace std;

	ifstream storedWidgets("widgets.txt");

// doesn't seem to work for either Microsoft vc++6 w/Dinkumware OR Borland 5.5:

	deque<Widget> wd1(istream_iterator<Widget>(storedWidgets));

// while this works with both:
	
	deque<Widget> wd(1,2);

	deque<list<Widget> > d2;
	d2++;

	deque<list<Widget> >::iterator it3;
	
	it3 = 10;
	
	wd.foo();

	deque<Widget>::iterator it2 = wd.clear();

	deque<Widget>::iterator it = wd.begin();
	wd = 10;
	string s(wd);
	string s2(d2);
	
	copy(istream_iterator<Widget>(storedWidgets), istream_iterator<Widget>(),
       back_inserter(wd));

	return 0;
}
