#include <iostream>
#include <map>
#include <list>
#include <algorithm>
#include <cmath>

const int values[] = { 1,2,3,4,5 };
const int NVALS = sizeof values / sizeof (int);

int main()
{
	using namespace std;

	list<int> l1, l2;
	
	typedef map<int, list<int> > valmap;

	valmap m2(1,2,3);

	valmap m;
	
	for (int i = 0; i < NVALS; i++)
		m.insert(make_pair(values[i], l1));

	valmap::iterator it = 100;
	
	m.insert(1,2);
	m.insert(make_pair(36, 10.57)); // fine, more convenient
	m.insert(m.end(), make_pair(40, 2.29)); // also fine

	return 0;
}

