#include <iostream>
#include <vector>
#include <set>
#include <string>

#include "Widget.h"

int main(int argc, char **argv)
{
	using namespace std;
	char cmdline[100] = "cl2 ";

	vector<int> v0("hello");
	vector<set<Widget> > v;
	v.foobar();
	string foo(1,2,3,4,5);
	for (int i = 1; i < argc; i++)
	{
		strcat(cmdline, argv[i]);
		strcat(cmdline, " ");
	}
	strcat(cmdline, " | perl d:\\src\\cl\\filt2.pl");

	cout << "complete command line: " << cmdline << endl;
	system(cmdline);
	return 0;
}
