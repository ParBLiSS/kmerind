#include <iostream>
#include <set>
#include <algorithm>
#include <deque>

int main()
{
	using namespace std;

	set<double> foo(1,2);
	deque<int> mydeq;
	set<deque<int> > mySet;

	for (int i = 0; i < 10; i++)
		mySet.insert(i,i);

	mySet.add(mydeq);
	mySet.add(10);

	set<int>::iterator firstFive = //find(mySet.begin(), mySet.end(), 5);
								  mydeq.first();
	firstFive += 5;

	if (firstFive != mySet.end())
		cout << "Found it!" << endl;
	else
		cout << "Not found." << endl;

	return 0;
}
