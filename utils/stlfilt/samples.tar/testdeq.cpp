#include <string>
#include <iostream>
#include <fstream>
#include <deque>
#include "Widget.h"

int main()
{
	using namespace std;

	ifstream storedWidgets("widgets.txt");

	deque<Widget> wd1(istream_iterator<Widget>(storedWidgets));

	deque<Widget> wd(1,2);

	wd.foo();

	deque<Widget>::iterator it2 = wd.clear();

	deque<Widget>::iterator it = wd.begin();
	wd = 10;
	string s(wd);
	
	copy(istream_iterator<Widget>(storedWidgets), istream_iterator<Widget>(),
       back_inserter(wd));

	return 0;
}
