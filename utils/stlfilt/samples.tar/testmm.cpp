#include <iostream>
#include <map>
#include <algorithm>
#include <cmath>
#include <string>
#include "Widget.h"
using namespace std;

const char *values[] = { "Cat", "Mouse", "Dog", "Rat", "Dog", "Hamster" };
const int NVALS = sizeof values / sizeof values[0];

struct intComp: public binary_function<int, int, bool>
{
	bool operator()(int a, int b) const
	{
		return a < b;
	}
};

int main()
{
	using namespace std;

	typedef multimap<string, Widget> MTYPE;

	MTYPE mm;
	multimap<int, int, intComp> m2;
	
	MTYPE::iterator it;
	int j = it;

	typedef MTYPE::size_type ST;

	for (int i = 0; i < NVALS; i++)
//		mm.insert(make_pair(values[i], Widget(i)));
		mm.insert(0);
	
	m2.insert(0);
	
	ST numErased = mm.erase("Dog");
	return 0;
}

