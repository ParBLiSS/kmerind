//
// (For stock Visual C++ 6, see changes required below)
//

#include <string>
#include <iostream>
#include <list>
#include <algorithm>


int main()
{
	using namespace std;

	const char *text1[] = { "this", "is", "a", "test", "of", "the",
		"emergency", "broadcast", "system" };
	const size_t nstrings1 = sizeof text1 / sizeof (const char *);

	const char *text2[] = { "just", "a", "few", "more!" };
	const size_t nstrings2 = sizeof text2 / sizeof (const char *);

	list<int *> foo("hello");

	foo.insert("bye");		// bad use of insert

	list<string> l1(text1, text1 + nstrings1), l2(text2, text2 + nstrings2);
/* For stock VC++ 6, replace the line above with:
	list<string> l1, l2;
	copy(text1, text1 + nstrings1, inserter(l1, l1.end()));	// initialize l1 from text1 array
	copy(text2, text2 + nstrings2, inserter(l2, l2.end()));	// initialize l2 from text2 array
*/
	
	l1.splice(l1.end(), l2);				//movel2�s elements tothe
											// end of l1; l2 is left empty
	l1.splice(l1.begin(), l1, --l1.end());	// move the last element of
											// l1 to the beginning of l1
	list<string>::iterator it(l1.end());	// make it point about 2/3rds

	for (unsigned int i = 1; i < l1.size() / 3; ++i) --it; // of the way down l1

	l2.splice( l2.begin(),					// move the first approx 2/3rds
			   l1, l1.begin(), it);			//of l1 to the front of l2
	return 0;
}
