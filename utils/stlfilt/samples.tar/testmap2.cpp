#include <iostream>
#include <map>
#include <algorithm>
#include <cmath>
#include <string>
#include "Widget.h"

const char *values[] = { "Cat", "Mouse", "Dog", "Rat", "Dog", "Hamster" };
const int NVALS = sizeof values / sizeof values[0];

int main()
{
	using namespace std;

	typedef map<int *, Widget> MTYPE;

	MTYPE mm;

	typedef MTYPE::size_type ST;

	for (int i = 0; i < NVALS; i++)
//		mm.insert(make_pair(values[i], Widget(i)));
		mm.insert(0);	// line 28
	
	ST numErased = mm.erase("Dog");		// line 32
	return 0;
}

