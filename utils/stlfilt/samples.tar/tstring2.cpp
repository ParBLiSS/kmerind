//
// test string class
//

#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

string myString("This is a test....ABC!",1,2,3);

class T {};

int main()
{
	
    string::iterator firstA = find(myString.begin(), myString.end(), 'A');

	if (firstA != myString.end())
	{
		cout << "We found it!" << endl;
		cout << "(the character after it is: " << *++firstA << ")" << endl;
	}
	else
		cout << "Didn't find it" << endl;

/*
	T t;
	string newString;

	newString = myString + t;
*/
	return 0;
}
