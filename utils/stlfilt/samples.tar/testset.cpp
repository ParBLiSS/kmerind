#include <iostream>
#include <set>
#include <algorithm>
using namespace std;

struct intComp: public binary_function<int, int, bool>
{
	bool operator()(int a, int b) const
	{
		return a < b;
	}
};

int main()
{
	using namespace std;

	set<double> foo(1,2);
	set<int> mySet;
	set<int,intComp> mySet2;
	
	set<int *> mypSet;

	for (int i = 0; i < 10; i++)
	{
		mySet.insert(i,i);
		mySet2.insert(i,i, i);
		mypSet.insert(i,i);
	}

	mySet.add("five");
	mySet2.add("abc");

	set<int>::iterator firstFive = //find(mySet.begin(), mySet.end(), 5);
								  50;

	if (firstFive != mySet.end())
		cout << "Found it!" << endl;
	else
		cout << "Not found." << endl;

	return 0;
}
