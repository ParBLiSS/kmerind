
#include <iostream>
#include <vector>
#include <string>

#include "Widget.h"

int main(int argc, char **argv)
{
	using namespace std;

	vector<int> v0("hello");
	vector<Widget **> v(1,2,3,4,5,6);
	v.foobar();

	return 0;
}
