#include <iostream>
#include <map>
#include <algorithm>
#include <cmath>
#include <string>
#include "Widget.h"

const char *values[] = { "Cat", "Mouse", "Dog", "Rat", "Dog", "Hamster" };
const int NVALS = sizeof values / sizeof values[0];

int main()
{
	using namespace std;

//	typedef multimap<string  , Widget **> MTYPE;
	typedef multimap<int * , int> MTYPE;

	MTYPE mm;

	string *sp;

	sp = 1;

	MTYPE::iterator it;
	int j = it;

	typedef MTYPE::size_type ST;

	for (int i = 0; i < NVALS; i++)
//		mm.insert(make_pair(values[i], Widget(i)));
		mm.insert(0);
	
	ST numErased = mm.erase("Dog");

	return 0;
}

